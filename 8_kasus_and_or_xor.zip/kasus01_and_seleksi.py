# KASUS 1: Seleksi peserta
aktif = True
nilai_memenuhi = True
prasyarat = True

lulus = aktif and nilai_memenuhi and prasyarat

if lulus:
    print("Peserta LULUS seleksi")
else:
    print("Peserta TIDAK LULUS seleksi")
