# KASUS 7: Peminjaman buku
kartu_aktif = True
buku_tersedia = True
tidak_ada_tunggakan = False

boleh_meminjam = kartu_aktif and buku_tersedia and tidak_ada_tunggakan

if boleh_meminjam:
    print("Peminjaman DISETUJUI")
else:
    print("Peminjaman DITOLAK")
