# KASUS 3: Lampu dengan XOR
saklar_a = True
saklar_b = False

lampu_menyala = saklar_a ^ saklar_b

if lampu_menyala:
    print("Lampu MENYALA")
else:
    print("Lampu MATI")
