# KASUS 4: Login akun
username_benar = True
password_benar = False

berhasil_login = username_benar and password_benar

if berhasil_login:
    print("Login BERHASIL")
else:
    print("Login GAGAL")
