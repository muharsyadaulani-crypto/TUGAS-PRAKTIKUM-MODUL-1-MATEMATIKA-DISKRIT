# KASUS 8: Pemeriksaan kendaraan
surat_lengkap = True
lampu_normal = False

boleh_masuk = surat_lengkap or lampu_normal
tepat_satu_kondisi = surat_lengkap ^ lampu_normal

if boleh_masuk:
    print("Minimal satu kondisi terpenuhi")
else:
    print("Tidak ada kondisi yang terpenuhi")

if tepat_satu_kondisi:
    print("Tepat SATU kondisi terpenuhi (XOR)")
else:
    print("XOR bernilai False")
