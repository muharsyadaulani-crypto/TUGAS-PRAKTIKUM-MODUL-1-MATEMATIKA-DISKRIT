# KASUS 2: Prioritas peserta
pengalaman = False
sertifikat = True

prioritas = pengalaman or sertifikat

if prioritas:
    print("Peserta mendapat PRIORITAS")
else:
    print("Peserta tidak mendapat prioritas")
