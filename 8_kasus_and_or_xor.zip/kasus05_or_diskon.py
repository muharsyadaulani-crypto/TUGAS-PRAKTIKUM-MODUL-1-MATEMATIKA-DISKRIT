# KASUS 5: Diskon pelanggan
anggota = False
belanja_besar = True

dapat_diskon = anggota or belanja_besar

if dapat_diskon:
    print("Pelanggan mendapat DISKON")
else:
    print("Pelanggan tidak mendapat diskon")
