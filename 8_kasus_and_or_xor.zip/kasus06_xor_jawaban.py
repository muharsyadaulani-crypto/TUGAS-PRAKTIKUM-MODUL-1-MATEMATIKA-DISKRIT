# KASUS 6: Jawaban pilihan ganda
jawaban_a = True
jawaban_b = True

tepat_satu_jawaban = jawaban_a ^ jawaban_b

if tepat_satu_jawaban:
    print("Hanya SATU jawaban yang dipilih")
else:
    print("Bukan tepat satu jawaban yang dipilih")
